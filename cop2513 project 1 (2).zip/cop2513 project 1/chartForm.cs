﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace cop2513_project_1
{
    public partial class chartForm : Form
    {
        DataView dataView;

        public chartForm()
        {
        }

        public chartForm(DataView dataView)
        {
            InitializeComponent();
            this.dataView = dataView;
        }

        internal void LoadChart(DataTable dataTable)
        {
            throw new NotImplementedException();
        }

        private void chartForm_Load(object sender, EventArgs e)
        {
            // Bind data to chart
            Series series_candlestick = new Series("Candlestick");
            series_candlestick.ChartType = SeriesChartType.Candlestick;
            series_candlestick.XValueMember = "Date";
            series_candlestick.YValuesPerPoint = 4;
            series_candlestick.YValueMembers = "close, low, open, high";
            series_candlestick.XValueType = ChartValueType.Date;
            series_candlestick.CustomProperties = "PriceUpColor=Green";
            series_candlestick.Color = Color.Red;
            series_candlestick["OpenCloseStyle"] = "Triangle";
            series_candlestick["ShowOpenClose"] = "Both";
            stockChart.Series.Clear();
            stockChart.Series.Add(series_candlestick);
            stockChart.DataSource = dataView;
        }
    }
}