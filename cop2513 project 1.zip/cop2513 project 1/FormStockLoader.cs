﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cop2513_project_1
{
    public partial class FormStockLoader : Form
    {
        public FormStockLoader()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonDownload_Click(object sender, EventArgs e)
        {
            Text = "We pressed the button";
        }

        private void buttonDownload_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Text = "I was loaded";
        }

        private void labelStartDate_Click(object sender, EventArgs e)
        {

        }

        private void radioButtonWeekly_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chartStock_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewStock_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
