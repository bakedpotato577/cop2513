﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace cop2513_project_1.Forms
{
    public partial class FormStockLoader : Form
    {
        public FormStockLoader()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FormStockLoader_Load(object sender, EventArgs e)
        {
            stockSymbolsComboBox.SelectedIndex = 0;
            periodComboBox.SelectedIndex = 0;
        }




        private void refreshFilenameButton_Click(object sender, EventArgs e)
        {
            string stockSymbol = stockSymbolsComboBox.SelectedItem.ToString();
            string periodType = periodComboBox.SelectedItem.ToString();
            DateTime startDate = startDateTimePicker.Value;
            DateTime endDate = endDateTimePicker.Value;

            string fileName = $"{stockSymbol}-{periodType}.CSV";
            filenameTextbox.Text = fileName.Trim();

            if (fileLocationLabel.Text.Length == 0)
            {
                fileLocationLabel.Text = System.AppDomain.CurrentDomain.BaseDirectory;
            }

            string directory = currentExecutableFolder();
            string dataDirectory = $@"{directory}Stock Data\";
            fileLocationLabel.Text = dataDirectory;

            string fileStock = filenameTextbox.Text;

            var fileCount = (from file in Directory.EnumerateFiles(dataDirectory, fileStock, SearchOption.AllDirectories)
                             select file).Count();
        }


        private string currentExecutableFolder()
        {
            return AppDomain.CurrentDomain.BaseDirectory;
        }

        static DataTable GetDataTableFromCsv(string path, bool isFirstRowHeader)
        {
            string header = isFirstRowHeader ? "Yes" : "No";

            string pathOnly = Path.GetDirectoryName(path);
            string fileName = Path.GetFileName(path);

            string sql = @"SELECT * FROM [" + fileName + "]";

            using (OleDbConnection connection = new OleDbConnection(
                      @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathOnly +
                      ";Extended Properties=\"Text;HDR=" + header + "\""))
            using (OleDbCommand command = new OleDbCommand(sql, connection))
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
            {
                DataTable dataTable = new DataTable();
                dataTable.Locale = CultureInfo.CurrentCulture;
                adapter.Fill(dataTable);
                return dataTable;
            }
        }
        public DataTable ImportFromCSVFileAsync(string filePath)
        {
            int rowNumber = 0;

            // "Date","Open","High","Low","Close","Volume"
            DataTable dt = new DataTable();
            dt.Columns.Add("Date");
            dt.Columns.Add("Open");
            dt.Columns.Add("High");
            dt.Columns.Add("Low");
            dt.Columns.Add("Close");
            dt.Columns.Add("Volume");


            // splitting the values using Split() command 
            foreach (var srLine in File.ReadAllLines(filePath))
            {
                if (rowNumber > 0)
                {
                    dt.Rows.Add(srLine.Split(','));
                }
                rowNumber++;
            }
            return dt;

        }

        private async Task btnLoad_ClickAsync(object sender, EventArgs e)
        {

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string stockSymbol = stockSymbolsComboBox.SelectedItem.ToString();
            string periodType = periodComboBox.SelectedItem.ToString();
            DateTime startDate = startDateTimePicker.Value;
            DateTime endDate = endDateTimePicker.Value;

            string fileName = $"{stockSymbol}-{periodType}.CSV";
            filenameTextbox.Text = fileName.Trim();

            if (fileLocationLabel.Text.Length == 0)
            {
                fileLocationLabel.Text = System.AppDomain.CurrentDomain.BaseDirectory;
            }

            string directory = currentExecutableFolder();
            string dataDirectory = $@"{directory}Stock Data\";
            fileLocationLabel.Text = dataDirectory;

            string fileStock = Path.Combine(dataDirectory.Trim(), filenameTextbox.Text.Trim());



            progressBar1.Visible = true;
            try
            {
                string startDateField = $"'{startDateTimePicker.Value.ToString("yyyy-MM-dd")}'";
              string endDateField = $"'{endDateTimePicker.Value.ToString("yyyy-MM-dd")}'";
                //DataTable dt = ImportFromCSVFileAsync(fileStock);

                DataTable dt = GetDataTableFromCsv(fileStock, true);

                string filtro = $"Date >= {startDateField} AND Date <= {endDateField}"; 
                DataView dv = new DataView(dt);
                dv.RowFilter = filtro; // query example = "id = 10"

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = null; // To clear the previous data before adding the new ones
                    dataGridView1.DataSource = dv;
                    stockChart.DataSource = dv;

                    stockChart.Series.Clear(); // Clear any previously loaded data

                    // Bind data to chart
                    Series series_candlestick = new Series("Candlestick");

                    series_candlestick.ChartType = SeriesChartType.Candlestick;
                    series_candlestick.XValueMember = "Date";
                    series_candlestick.YValuesPerPoint = 4;
                    series_candlestick.YValueMembers = "close, low, open, high";
                    series_candlestick.XValueType = ChartValueType.Date;
                    series_candlestick.CustomProperties = "PriceUpColor=Green";
                    series_candlestick.Color = Color.Red;
                    series_candlestick["OpenCloseStyle"] = "Triangle";
                    series_candlestick["ShowOpenClose"] = "Both";
                    stockChart.Series.Add(series_candlestick);

                    stockChart.DataSource = dv;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

            progressBar1.Visible = false;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void stockSymbolsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void endDateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
